/*
 * 7led.c
 *
 *  Created on: Nov 7, 2024
 *      Author: ADMIN
 */
#include "7led.h"
void sevenledsetA(int value)
{
	switch(value)
	{
		case 0:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA2_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA6_Pin, GPIO_PIN_SET);
			break;
		case 1:
			HAL_GPIO_WritePin(GPIOA, SEGA1_Pin | SEGA2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_SET);
			break;
		case 2:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA3_Pin | SEGA4_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA2_Pin | SEGA5_Pin, GPIO_PIN_SET);
			break;
		case 3:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA2_Pin | SEGA3_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA4_Pin | SEGA5_Pin, GPIO_PIN_SET);
			break;
		case 4:
			HAL_GPIO_WritePin(GPIOA, SEGA1_Pin | SEGA2_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA3_Pin | SEGA4_Pin, GPIO_PIN_SET);
			break;
		case 5:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA2_Pin | SEGA3_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA1_Pin | SEGA4_Pin, GPIO_PIN_SET);
			break;
		case 6:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA2_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA1_Pin, GPIO_PIN_SET);
			break;
		case 7:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA3_Pin | SEGA4_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_SET);
			break;
		case 8:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA2_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			break;
		case 9:
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA1_Pin | SEGA2_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin | SEGA6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA4_Pin, GPIO_PIN_SET);
			break;
		default:
			HAL_GPIO_WritePin(GPIOA, SEGA1_Pin | SEGA2_Pin | SEGA3_Pin | SEGA4_Pin | SEGA5_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, SEGA0_Pin | SEGA6_Pin, GPIO_PIN_SET);
			break;
	}
}

void sevenledsetB(int value)
{
	switch(value)
	{
		case 0:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB2_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB6_Pin, GPIO_PIN_SET);
			break;
		case 1:
			HAL_GPIO_WritePin(GPIOB, SEGB1_Pin | SEGB2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_SET);
			break;
		case 2:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB3_Pin | SEGB4_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB2_Pin | SEGB5_Pin, GPIO_PIN_SET);
			break;
		case 3:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB2_Pin | SEGB3_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB4_Pin | SEGB5_Pin, GPIO_PIN_SET);
			break;
		case 4:
			HAL_GPIO_WritePin(GPIOB, SEGB1_Pin | SEGB2_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB3_Pin | SEGB4_Pin, GPIO_PIN_SET);
			break;
		case 5:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB2_Pin | SEGB3_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB1_Pin | SEGB4_Pin, GPIO_PIN_SET);
			break;
		case 6:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB2_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB1_Pin, GPIO_PIN_SET);
			break;
		case 7:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB3_Pin | SEGB4_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_SET);
			break;
		case 8:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB2_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			break;
		case 9:
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB1_Pin | SEGB2_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin | SEGB6_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB4_Pin, GPIO_PIN_SET);
			break;
		default:
			HAL_GPIO_WritePin(GPIOB, SEGB1_Pin | SEGB2_Pin | SEGB3_Pin | SEGB4_Pin | SEGB5_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOB, SEGB0_Pin | SEGB6_Pin, GPIO_PIN_SET);
			break;
	}
}

