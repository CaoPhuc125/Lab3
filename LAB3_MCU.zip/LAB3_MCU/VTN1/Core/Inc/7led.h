/*
 * 7led.h
 *
 *  Created on: Nov 7, 2024
 *      Author: ADMIN
 */

#ifndef INC_7LED_H_
#define INC_7LED_H_

#include "main.h"

void sevenledsetA(int value);
void sevenledsetB(int value);



#endif /* INC_7LED_H_ */
