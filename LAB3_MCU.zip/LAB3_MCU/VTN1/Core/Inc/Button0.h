/*
 * Button0.h
 *
 *  Created on: Nov 7, 2024
 *      Author: ADMIN
 */

#ifndef INC_BUTTON0_H_
#define INC_BUTTON0_H_

#include "main.h"

extern int button0_trigger;

void GetkeyInput0();



#endif /* INC_BUTTON0_H_ */
