/*
 * Button1.h
 *
 *  Created on: Nov 7, 2024
 *      Author: ADMIN
 */

#ifndef INC_BUTTON1_H_
#define INC_BUTTON1_H_

#include "main.h"

extern int button1_trigger;
extern int button1_trigger_long;

void GetkeyInput1();


#endif /* INC_BUTTON1_H_ */
