/*
 * Button2.h
 *
 *  Created on: Nov 7, 2024
 *      Author: ADMIN
 */

#ifndef INC_BUTTON2_H_
#define INC_BUTTON2_H_

#include "main.h"

extern int button2_trigger;

void GetkeyInput2();

#endif /* INC_BUTTON2_H_ */
